//
//  bridge.h
//  WebServiceExample
//
//  Created by Regan Hsu on 7/29/15.
//  Copyright (c) 2015 Regan Hsu. All rights reserved.
//
#import "AFNetworking/AFNetworking.h"
#ifndef WebServiceExample_bridge_h
#define WebServiceExample_bridge_h


#endif
